<?php

namespace Psonio\SiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PsonioSiteBundle extends Bundle
{
}
